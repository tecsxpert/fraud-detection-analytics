-- SQLite
SELECT * FROM transactions;